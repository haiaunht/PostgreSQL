#!/usr/bin/env node

import { v4 } from "uuid"

console.log(v4())
