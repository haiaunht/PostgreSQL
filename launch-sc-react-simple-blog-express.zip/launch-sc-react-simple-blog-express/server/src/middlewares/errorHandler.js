import errorHandler from "errorhandler"

export default errorHandler
