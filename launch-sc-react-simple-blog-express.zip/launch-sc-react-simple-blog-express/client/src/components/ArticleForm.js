import React, { useState, useEffect } from "react"


const ArticleForm = props => {
  const [articleRecord, setArticleRecord] = useState({
    title: "",
    content: ""
  })

  const handleChangeInput = event => {
    event.preventDefault()
    setArticleRecord({
      ...articleRecord,
      [event.currentTarget.name]: event.currentTarget.value
    })
  }

  const handleSubmit = event => {
    event.preventDefault()
    props.addNewArticle(articleRecord)
    setArticleRecord({
      title: "",
      content: ""
    })
  }
  
  return (
    <form className="new-article-form callout" onSubmit={handleSubmit}>
      <label>
        Article Title:
        <input
          name="title"
          id="title"
          type="text"
          onChange={handleChangeInput}
        />
      </label>
      <label>
        Article Content:
        <textarea
          name="content"
          id="content"
          onChange={handleChangeInput}
        />
      </label>

      <div className="button-group">
        <button className="button">Clear</button>
        <input className="button" type="submit" value="Submit" />
      </div>
    </form>
  )
}

export default ArticleForm
