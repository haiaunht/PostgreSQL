import React, { useState } from "react"
import ErrorList from "./ErrorList"

const NoteForm = props => {
  const [noteRecord, setNoteRecord] = useState({
    date: "",
    title: "",
    body: ""
  })
  const [errors, setErrors] = useState([])

  const addNewNote = async () => {
    try {
      const response = await fetch("/api/v1/notes", {
        method: "POST",
        headers: new Headers({
          "Content-Type": "application/json"
        }),
        body: JSON.stringify(noteRecord)
      })
      if (!response.ok) {
        if(response.status === 422) {
          const body = await response.json()
          return setErrors(body.errors)
        } else {
          const errorMessage = `${response.status} (${response.statusText})`
          const error = new Error(errorMessage)
          throw(error)
        }
      } else {
        const body = await response.json()
        console.log("Posted successfully!", body);
      }
    } catch(err) {
      console.error(`Error in fetch: ${err.message}`)
    }
  }

  const handleChange = (event) => {
    event.preventDefault()
    setNoteRecord({
      ...noteRecord,
      [event.currentTarget.name]: event.currentTarget.value
    })
  }

  const validForSubmission = () => {
    let submitErrors = {}
    const requiredFields = ["date", "title", 'body']
    requiredFields.forEach(field => {
      if (noteRecord[field].trim() === "") {
        submitErrors = {...submitErrors, [field]:"is blank"}
      }
    })

    setErrors(submitErrors)
    return _.isEmpty(submitErrors)
  }

  const handleSubmit = (event) => {
    event.preventDefault()
    if(validForSubmission()) {
      addNewNote()
    }
  }

  return (
    <form onSubmit={handleSubmit}>
      <ErrorList errors = {errors}/>
      <h1>Add a New Note</h1>
      <label htmlFor="date">Date
        <input
          id="date"
          type="date"
          name="date"
          onChange={handleChange}
          value={noteRecord.date}
        />
      </label>

      <label htmlFor="title">Title
        <input
          id="title"
          type="text"
          name="title"
          onChange={handleChange}
          value={noteRecord.title}
        />
      </label>

      <label htmlFor="body">Page Count
        <input
          id="body"
          type="text"
          name="body"
          onChange={handleChange}
          value={noteRecord.body}
        />
      </label>     

      <input type="submit" value="Add this Note" />
    </form>
  )
}

export default NoteForm