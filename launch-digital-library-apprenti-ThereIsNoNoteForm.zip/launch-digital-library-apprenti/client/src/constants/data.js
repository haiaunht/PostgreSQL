const data = {
  question: {
    id: 1,
    body: "What is the best JavaScript Framework?",
    correctAnswerId: 3,
    answers: [
      {
        id: 1,
        body: "Ember"
      },
      {
        id: 2,
        body: "Angular 2"
      },
      {
        id: 3,
        body: "React"
      },
      {
        id: 4,
        body: "Rails"
      }
    ]
  }
};

export default data;
